# math_ops.py - initially buggy
def divide_or_fallback(a, b, fallback=0.0):
    if b == 0:
        return fallback
    return a / b

def safe_mean(numbers):
    if not numbers:
        return 0.0
    return sum(numbers) / len(numbers)
