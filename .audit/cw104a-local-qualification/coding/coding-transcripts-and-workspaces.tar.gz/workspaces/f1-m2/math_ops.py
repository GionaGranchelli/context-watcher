def divide_or_fallback(a, b, fallback=0.0):
    try:
        return a / b
    except ZeroDivisionError:
        return fallback

def safe_mean(numbers):
    try:
        return sum(numbers) / len(numbers)
    except ZeroDivisionError:
        return 0.0
