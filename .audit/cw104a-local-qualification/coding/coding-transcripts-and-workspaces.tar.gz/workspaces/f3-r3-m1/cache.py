# cache.py
class CachedStore:
    def __init__(self, backing_store):
        self.backing_store = backing_store
        self.cache = {}
    def get(self, k):
        if k in self.cache:
            return self.cache[k]
        v = self.backing_store.get(k)
        if v is not None:
            self.cache[k] = v
        return v
    def put(self, k, v):
        self.cache[k] = v
        self.backing_store.put(k, v)
